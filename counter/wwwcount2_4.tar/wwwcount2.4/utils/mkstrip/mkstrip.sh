#!/bin/sh
#mkstrip \
#zero.gif one.gif two.gif three.gif four.gif five.gif six.gif seven.gif \
#eight.gif nine.gif col.gif am.gif pm.gif co.gif da.gif>strip.gif

#mkstrip \
#zero.gif one.gif two.gif three.gif four.gif five.gif six.gif seven.gif \
#eight.gif nine.gif>strip.gif
mkstrip \
zero.gif one.gif two.gif three.gif four.gif five.gif six.gif seven.gif \
eight.gif nine.gif colon.gif am.gif pm.gif comma.gif dash.gif>strip.gif
