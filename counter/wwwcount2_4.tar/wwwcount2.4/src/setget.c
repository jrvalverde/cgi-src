/*
** set and gets some static values
*/

#include "combine.h"
#include "count.h"

static int 
    s_do_cache=1,
    s_expires=300;

/* set the value of s_do_cache to the passed value */
/* no checking is done */
void setCache(cache)
int
    cache;
{
    s_do_cache=cache;
}

/* return the last set value of s_do_cache */
int doHTTPcache()
{
    return(s_do_cache);
}



/* set the value of s_expires to the passed value */
/* no checking is done */
void setExpire(exp)
int
    exp;
{
    s_expires=exp;
}

/* return the last set value of s_expires */
int getExpireOffset()
{
    return(s_expires);
}
