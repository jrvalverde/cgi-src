#!/bin/sh
#
# it's not for you
# muquit, nov-24-1997
#

VER=`cat VERSION`
DEST_DIR="$HOME/public_html"
ARC="wwwcount$VER.tar.gz"
ARC_DIR="$DEST_DIR/src/wwwcount$VER"

F1="docs/Count.html"
F2="docs/Count2_4-ex.html"
F3="docs/CountNT.html"
FDIR="docs/Count2.4"


HOST=`hostname`
if [ .$HOST = .chaos ]; then
    cp $ARC $ARC_DIR
    cp $F1 $DEST_DIR
    cp $F2 $DEST_DIR
#    cp $F3 $DEST_DIR
    cp -r $FDIR $DEST_DIR
else
    echo "wrong host"
    exit 0
fi
