#ifdef __VMS
#include <stdlib.h>
#include <string.h>
#endif

#include "bigplus.h"


int main(int argc,char **argv)
{
    bc_num
        n1,n2,
        result;

    char
        str[100];

    char
        str2[100];

    bc_num
        num;

    int
        scale;


    if (argc != 3)
    {
        (void) fprintf(stderr,"usage: %s <num1> <num2>\n",argv[0]);
        exit(1);
    }


    n1=new_num(100,0);
    n2=new_num(100,0);
    result=new_num(100,0);

    (void) strcpy(str,argv[1]);
    (void) strcpy(str2,argv[2]);
    scale=0;

    str2num(&n1,str,0);
    str2num(&n2,str2,0);
    bc_add (n1,n2,&result,0);
    (void) fprintf(stderr,"%s\n",num2str(result));
    free_num(&result);
    exit(1);
}
