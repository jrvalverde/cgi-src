I've entered Comm.pl into the Perl 5 Modules Server:

	http://franz.ww.TU-Berlin.DE:80/modulelist/

From there it is mirrored to the CPAN (Comprehensive Perl Archive Network?)
mirrors, E.g.:

 USA 
            ftp://ftp.cis.ufl.edu/pub/perl/CPAN/ 
            ftp://ftp.delphi.com/pub/mirrors/packages/perl/CPAN/ 
            ftp://ftp.sterling.com/programming/languages/perl/ 
            ftp://janus.sedl.org/pub/mirrors/CPAN/ 
            ftp://uiarchive.cso.uiuc.edu/pub/lang/perl/CPAN/ 

It will be under my name on these servers, since it isn't truely a Perl5
module (I guess -- I hasn't shown up there yet, anyway):

	ftp://ftp.sterling.com/programming/languages/perl/authors/Eric_Arnold

